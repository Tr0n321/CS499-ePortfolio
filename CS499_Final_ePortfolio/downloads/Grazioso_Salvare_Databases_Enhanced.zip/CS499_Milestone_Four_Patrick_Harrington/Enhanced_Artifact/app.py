"""Grazioso Salvare interactive dashboard.

This refactored entry point separates presentation, configuration, filter
rules, and database access so each concern can be maintained and tested
independently.
"""

from __future__ import annotations

import base64
import logging
from pathlib import Path
from typing import Any

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dash_table, dcc, html

from animal_shelter import AnimalShelter, AnimalShelterError
from config import ConfigurationError, MongoSettings
from filters import FILTER_OPTIONS, get_rescue_query, rank_candidates
from logger_config import configure_logging

LOGGER = logging.getLogger(__name__)
ASSET_DIR = Path(__file__).resolve().parent / "assets"
LOGO_PATH = ASSET_DIR / "Grazioso Salvare Logo.png"


def load_data(
    repository: AnimalShelter,
    query: dict[str, Any],
    filter_type: str = "reset",
    limit: int = 100,
) -> pd.DataFrame:
    """Read, rank, and normalize rescue candidates for the dashboard."""
    try:
        records = repository.read(query, limit=min(limit, 500))
    except AnimalShelterError:
        LOGGER.exception("Dashboard data load failed.")
        return pd.DataFrame()

    ranked_records = rank_candidates(records, filter_type, limit=limit)
    frame = pd.DataFrame.from_records(ranked_records)
    if "_id" in frame.columns:
        frame = frame.drop(columns=["_id"])
    return frame


def encode_logo(path: Path = LOGO_PATH) -> str:
    """Return a data URI for the dashboard logo, or an empty string."""
    if not path.is_file():
        LOGGER.warning("Logo file not found at %s.", path)
        return ""
    return base64.b64encode(path.read_bytes()).decode("ascii")


def create_app(repository: AnimalShelter) -> Dash:
    """Build the Dash application and register callbacks."""
    initial_frame = load_data(repository, {})
    encoded_logo = encode_logo()

    app = Dash(__name__)
    app.title = "Grazioso Salvare Dashboard"

    app.layout = html.Div(
        [
            html.Center(
                [
                    html.H1("Grazioso Salvare Dashboard"),
                    html.H4("Patrick Harrington"),
                    html.Img(
                        src=f"data:image/png;base64,{encoded_logo}" if encoded_logo else "",
                        style={"height": "150px"} if encoded_logo else {"display": "none"},
                        alt="Grazioso Salvare logo",
                    ),
                ]
            ),
            html.Hr(),
            html.Div(
                [
                    html.Label("Rescue Type Filter:"),
                    dcc.RadioItems(
                        id="filter-type",
                        options=FILTER_OPTIONS,
                        value="reset",
                        inline=True,
                    ),
                ],
                style={"marginBottom": "20px"},
            ),
            html.Div(id="status-message", role="status"),
            html.Hr(),
            dash_table.DataTable(
                id="datatable-id",
                columns=[{"name": name, "id": name} for name in initial_frame.columns],
                data=initial_frame.to_dict("records"),
                page_size=10,
                sort_action="native",
                filter_action="native",
                row_selectable="single",
                selected_rows=[0] if not initial_frame.empty else [],
                style_table={"overflowX": "auto"},
                style_cell={
                    "textAlign": "left",
                    "minWidth": "120px",
                    "width": "120px",
                    "maxWidth": "180px",
                    "whiteSpace": "normal",
                },
            ),
            html.Br(),
            html.Hr(),
            html.Div(
                [
                    html.Div(id="graph-id", style={"width": "48%", "display": "inline-block", "verticalAlign": "top"}),
                    html.Div(id="map-id", style={"width": "48%", "display": "inline-block", "verticalAlign": "top"}),
                ]
            ),
        ],
        style={"maxWidth": "1400px", "margin": "0 auto", "padding": "20px"},
    )

    @app.callback(
        Output("datatable-id", "data"),
        Output("datatable-id", "columns"),
        Output("datatable-id", "selected_rows"),
        Output("status-message", "children"),
        Input("filter-type", "value"),
    )
    def update_dashboard(filter_type: str):
        query = get_rescue_query(filter_type)
        frame = load_data(repository, query, filter_type)
        columns = [{"name": name, "id": name} for name in frame.columns]
        records = frame.to_dict("records")
        selected = [0] if records else []
        profile_note = " ranked by rescue suitability" if filter_type != "reset" else ""
        status = f"{len(records)} record(s) loaded{profile_note}."
        return records, columns, selected, status

    @app.callback(
        Output("graph-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
    )
    def update_graphs(view_data: list[dict[str, Any]] | None):
        if not view_data:
            return html.H4("No data available")

        frame = pd.DataFrame.from_records(view_data)
        if "breed" not in frame.columns:
            return html.H4("Breed data not available")

        figure = px.pie(frame, names="breed", title="Breed Distribution of Filtered Results")
        return dcc.Graph(figure=figure)

    @app.callback(
        Output("map-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows"),
    )
    def update_map(
        view_data: list[dict[str, Any]] | None,
        selected_rows: list[int] | None,
    ):
        if not view_data:
            return html.H4("No map data to display")

        frame = pd.DataFrame.from_records(view_data)
        required = {"location_lat", "location_long"}
        if not required.issubset(frame.columns):
            return html.H4("Location data not available")

        row_index = selected_rows[0] if selected_rows else 0
        if row_index < 0 or row_index >= len(frame):
            row_index = 0

        row = frame.iloc[row_index]
        latitude = row["location_lat"]
        longitude = row["location_long"]
        if pd.isna(latitude) or pd.isna(longitude):
            return html.H4("Selected record does not contain valid coordinates")

        animal_name = row.get("name", "Unknown")
        breed = row.get("breed", "Unknown")
        return dl.Map(
            center=[latitude, longitude],
            zoom=10,
            style={"width": "100%", "height": "500px"},
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[latitude, longitude],
                    children=[
                        dl.Tooltip(str(breed)),
                        dl.Popup([html.H4(str(animal_name)), html.P(f"Breed: {breed}")]),
                    ],
                ),
            ],
        )

    return app


def main() -> None:
    """Configure dependencies and start the development server."""
    configure_logging()
    try:
        settings = MongoSettings.from_environment()
        repository = AnimalShelter(settings)
    except (ConfigurationError, AnimalShelterError) as exc:
        LOGGER.error("Application startup failed: %s", exc)
        raise SystemExit(1) from exc

    app = create_app(repository)
    try:
        app.run(host="0.0.0.0", port=8050, debug=False)
    finally:
        repository.close()


if __name__ == "__main__":
    main()
