"""Secure MongoDB data-access layer for Austin Animal Center records.

Milestone Four database enhancements add schema-aware validation, safe single-
record mutations, managed indexes, bounded reads, aggregation queries, audit
fields, and clearer database-specific exceptions.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote_plus

from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError, PyMongoError

from config import MongoSettings

LOGGER = logging.getLogger(__name__)
MAX_READ_LIMIT = 500
ALLOWED_SORT_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "name",
    "age_upon_outcome_in_weeks",
    "date_of_birth",
    "datetime",
}
REQUIRED_CREATE_FIELDS = {"animal_id", "animal_type", "breed"}
STRING_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "name",
    "color",
    "sex_upon_outcome",
    "outcome_type",
    "outcome_subtype",
}
NUMERIC_FIELDS = {
    "age_upon_outcome_in_weeks",
    "location_lat",
    "location_long",
}


class AnimalShelterError(RuntimeError):
    """Base exception for repository failures."""


class AnimalValidationError(AnimalShelterError, ValueError):
    """Raised when an animal document fails application validation."""


class AnimalConflictError(AnimalShelterError):
    """Raised when a unique record already exists."""


class AnimalNotFoundError(AnimalShelterError):
    """Raised when a requested animal record does not exist."""


class AnimalShelter:
    """Provide validated and bounded CRUD access to the shelter collection."""

    def __init__(
        self,
        settings: MongoSettings,
        client: MongoClient | None = None,
        ensure_indexes: bool = True,
    ):
        """Initialize the repository and verify the database connection.

        Args:
            settings: Validated MongoDB settings.
            client: Optional client used for dependency injection and testing.
            ensure_indexes: Create the documented indexes during startup.

        Raises:
            AnimalShelterError: If MongoDB cannot be reached or indexed.
        """
        self._settings = settings
        self.client = client or MongoClient(
            self._build_uri(settings),
            serverSelectionTimeoutMS=5000,
        )
        self.database = self.client[settings.database]
        self.collection: Collection = self.database[settings.collection]

        try:
            self.client.admin.command("ping")
            if ensure_indexes:
                self.ensure_indexes()
            LOGGER.info(
                "Connected to MongoDB database '%s', collection '%s'.",
                settings.database,
                settings.collection,
            )
        except PyMongoError as exc:
            LOGGER.exception("MongoDB startup failed.")
            raise AnimalShelterError("Unable to initialize MongoDB.") from exc

    @staticmethod
    def _build_uri(settings: MongoSettings) -> str:
        username = quote_plus(settings.username)
        password = quote_plus(settings.password)
        return f"mongodb://{username}:{password}@{settings.host}:{settings.port}"

    @staticmethod
    def _require_mapping(value: Mapping[str, Any] | None, name: str) -> dict[str, Any]:
        if value is None or not isinstance(value, Mapping):
            raise AnimalValidationError(f"{name} must be a mapping.")
        return dict(value)

    @staticmethod
    def _clean_document(
        value: Mapping[str, Any],
        *,
        require_create_fields: bool,
    ) -> dict[str, Any]:
        """Normalize supported values and reject malformed field content."""
        document = AnimalShelter._require_mapping(value, "data")
        if not document:
            raise AnimalValidationError("data cannot be empty.")

        cleaned: dict[str, Any] = {}
        for field, raw_value in document.items():
            if field.startswith("$") or "." in field:
                raise AnimalValidationError(f"Unsafe field name: {field}")

            if field in STRING_FIELDS:
                if raw_value is None:
                    cleaned[field] = None
                    continue
                if not isinstance(raw_value, str):
                    raise AnimalValidationError(f"{field} must be a string.")
                text = raw_value.strip()
                if field in REQUIRED_CREATE_FIELDS and not text:
                    raise AnimalValidationError(f"{field} cannot be blank.")
                cleaned[field] = text
            elif field in NUMERIC_FIELDS:
                if raw_value is None:
                    cleaned[field] = None
                    continue
                if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
                    raise AnimalValidationError(f"{field} must be numeric.")
                cleaned[field] = float(raw_value)
            else:
                cleaned[field] = raw_value

        if require_create_fields:
            missing = sorted(REQUIRED_CREATE_FIELDS - cleaned.keys())
            if missing:
                raise AnimalValidationError(
                    "Missing required field(s): " + ", ".join(missing)
                )
        return cleaned

    @staticmethod
    def _validate_query(query: Mapping[str, Any] | None) -> dict[str, Any]:
        """Validate the outer query structure to reduce accidental operator misuse."""
        criteria = AnimalShelter._require_mapping(query or {}, "query")
        for key in criteria:
            if not isinstance(key, str) or not key:
                raise AnimalValidationError("Query keys must be nonempty strings.")
            if key.startswith("$") and key not in {"$and", "$or"}:
                raise AnimalValidationError(f"Unsupported top-level query operator: {key}")
        return criteria

    def ensure_indexes(self) -> list[str]:
        """Create indexes that support uniqueness and common dashboard queries."""
        try:
            names = [
                self.collection.create_index(
                    [("animal_id", ASCENDING)],
                    unique=True,
                    name="ux_animals_animal_id",
                    partialFilterExpression={"animal_id": {"$type": "string"}},
                ),
                self.collection.create_index(
                    [("animal_type", ASCENDING), ("breed", ASCENDING)],
                    name="ix_animals_type_breed",
                ),
                self.collection.create_index(
                    [
                        ("animal_type", ASCENDING),
                        ("sex_upon_outcome", ASCENDING),
                        ("age_upon_outcome_in_weeks", ASCENDING),
                    ],
                    name="ix_animals_rescue_filter",
                ),
            ]
            LOGGER.info("Verified MongoDB indexes: %s", ", ".join(names))
            return names
        except PyMongoError as exc:
            LOGGER.exception("Index creation failed.")
            raise AnimalShelterError("Unable to create database indexes.") from exc

    def create(self, data: Mapping[str, Any]) -> str:
        """Validate and insert one animal record, returning its identifier."""
        document = self._clean_document(data, require_create_fields=True)
        timestamp = datetime.now(timezone.utc)
        document.setdefault("created_at", timestamp)
        document["updated_at"] = timestamp

        try:
            result = self.collection.insert_one(document)
            LOGGER.info("Inserted animal record %s.", result.inserted_id)
            return str(result.inserted_id)
        except DuplicateKeyError as exc:
            LOGGER.warning("Duplicate animal_id rejected: %s", document.get("animal_id"))
            raise AnimalConflictError("animal_id already exists.") from exc
        except PyMongoError as exc:
            LOGGER.exception("Create operation failed.")
            raise AnimalShelterError("Unable to create animal record.") from exc

    def read(
        self,
        query: Mapping[str, Any] | None = None,
        *,
        limit: int = 100,
        sort: Sequence[tuple[str, int]] | None = None,
        projection: Mapping[str, int | bool] | None = None,
    ) -> list[dict[str, Any]]:
        """Return matching records using bounded reads and allow-listed sorting."""
        criteria = self._validate_query(query)
        if not isinstance(limit, int) or isinstance(limit, bool):
            raise AnimalValidationError("limit must be an integer.")
        if not 1 <= limit <= MAX_READ_LIMIT:
            raise AnimalValidationError(
                f"limit must be between 1 and {MAX_READ_LIMIT}."
            )

        sort_spec: list[tuple[str, int]] = []
        for field, direction in sort or []:
            if field not in ALLOWED_SORT_FIELDS:
                raise AnimalValidationError(f"Sorting by '{field}' is not allowed.")
            if direction not in {ASCENDING, DESCENDING, 1, -1}:
                raise AnimalValidationError("Sort direction must be 1 or -1.")
            sort_spec.append((field, int(direction)))

        fields = dict(projection or {"_id": False})
        try:
            cursor = self.collection.find(criteria, fields)
            if sort_spec:
                cursor = cursor.sort(sort_spec)
            records = list(cursor.limit(limit))
            LOGGER.info("Read %d animal record(s).", len(records))
            return records
        except PyMongoError as exc:
            LOGGER.exception("Read operation failed.")
            raise AnimalShelterError("Unable to read animal records.") from exc

    def update_one(self, animal_id: str, new_values: Mapping[str, Any]) -> bool:
        """Safely update exactly one record identified by ``animal_id``."""
        if not isinstance(animal_id, str) or not animal_id.strip():
            raise AnimalValidationError("animal_id is required.")
        updates = self._clean_document(new_values, require_create_fields=False)
        updates.pop("animal_id", None)
        updates.pop("created_at", None)
        if not updates:
            raise AnimalValidationError("No editable values were supplied.")
        updates["updated_at"] = datetime.now(timezone.utc)

        try:
            result = self.collection.update_one(
                {"animal_id": animal_id.strip()},
                {"$set": updates},
            )
            if result.matched_count == 0:
                raise AnimalNotFoundError(f"Animal '{animal_id}' was not found.")
            LOGGER.info("Updated animal record %s.", animal_id)
            return result.modified_count > 0
        except AnimalNotFoundError:
            raise
        except PyMongoError as exc:
            LOGGER.exception("Update operation failed.")
            raise AnimalShelterError("Unable to update animal record.") from exc

    def delete_one(self, animal_id: str) -> bool:
        """Safely delete exactly one record identified by ``animal_id``."""
        if not isinstance(animal_id, str) or not animal_id.strip():
            raise AnimalValidationError("animal_id is required.")
        try:
            result = self.collection.delete_one({"animal_id": animal_id.strip()})
            if result.deleted_count == 0:
                raise AnimalNotFoundError(f"Animal '{animal_id}' was not found.")
            LOGGER.info("Deleted animal record %s.", animal_id)
            return True
        except AnimalNotFoundError:
            raise
        except PyMongoError as exc:
            LOGGER.exception("Delete operation failed.")
            raise AnimalShelterError("Unable to delete animal record.") from exc

    def count_by_breed(
        self,
        query: Mapping[str, Any] | None = None,
        *,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Return breed counts using a server-side aggregation pipeline."""
        criteria = self._validate_query(query)
        if not 1 <= limit <= 100:
            raise AnimalValidationError("aggregation limit must be between 1 and 100.")
        pipeline: list[dict[str, Any]] = []
        if criteria:
            pipeline.append({"$match": criteria})
        pipeline.extend(
            [
                {"$match": {"breed": {"$type": "string", "$ne": ""}}},
                {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
                {"$sort": {"count": -1, "_id": 1}},
                {"$limit": limit},
                {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
            ]
        )
        try:
            results = list(self.collection.aggregate(pipeline))
            LOGGER.info("Aggregated %d breed count(s).", len(results))
            return results
        except PyMongoError as exc:
            LOGGER.exception("Breed aggregation failed.")
            raise AnimalShelterError("Unable to aggregate breed statistics.") from exc

    def database_health(self) -> dict[str, Any]:
        """Return a small, non-sensitive database health summary."""
        try:
            estimated = self.collection.estimated_document_count()
            index_names = sorted(self.collection.index_information().keys())
            return {
                "database": self._settings.database,
                "collection": self._settings.collection,
                "estimated_records": estimated,
                "indexes": index_names,
            }
        except PyMongoError as exc:
            LOGGER.exception("Database health check failed.")
            raise AnimalShelterError("Unable to inspect database health.") from exc

    def close(self) -> None:
        """Release the MongoDB client connection."""
        self.client.close()
        LOGGER.info("MongoDB connection closed.")
