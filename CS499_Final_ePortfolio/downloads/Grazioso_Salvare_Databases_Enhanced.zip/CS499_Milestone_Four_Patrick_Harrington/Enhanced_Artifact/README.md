# Grazioso Salvare Dashboard - Algorithms and Data Structures Enhancement

This folder contains the progressively enhanced CS-340 dashboard prepared for CS 499 Milestone Three. It retains the software design and security improvements from Milestone Two and adds a transparent rescue-candidate selection algorithm.

## Milestone Three enhancement summary

- Replaced static query dictionaries with immutable `RescueProfile` data structures.
- Added dynamic MongoDB query construction from centralized profile rules.
- Added a weighted suitability-scoring algorithm for breed, sex, and age.
- Added partial age scoring based on distance from the preferred range midpoint to reduce ties.
- Added stable top-k ranking with `heapq.nlargest`.
- Enriched displayed records with `match_score` and `match_reasons` for explainability.
- Added unit tests for profile lookup, query generation, scoring, ranking, limits, and reset behavior.

## Algorithmic design

For a selected rescue category, MongoDB first performs a coarse pre-filter. Each returned candidate is then scored on a 100-point scale:

- Preferred breed: 50 points
- Preferred sex: 20 points
- Age suitability: up to 30 points

Age points vary according to the animal's distance from the midpoint of the preferred age range. The dashboard selects the best `k` candidates with a bounded heap. For `n` candidate records and `k` displayed results, ranking requires `O(n log k)` time and `O(k)` auxiliary space, rather than fully sorting every candidate with `O(n log n)` time.

## Project structure

- `app.py` - Dash layout, callbacks, ranking integration, and startup logic
- `animal_shelter.py` - validated MongoDB CRUD repository
- `config.py` - immutable environment-based settings
- `filters.py` - rescue profiles, query generation, scoring, and ranking algorithms
- `logger_config.py` - centralized logging setup
- `tests/test_filters.py` - unit tests for algorithms and data structures
- `assets/` - dashboard logo

## Setup

1. Create and activate a Python virtual environment.
2. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

3. Set the required MongoDB environment variables using `.env.example` as a guide.
4. Run the application:

   ```bash
   python app.py
   ```

5. Open `http://127.0.0.1:8050` in a browser.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Security note

`.env.example` contains placeholders only. Real credentials must remain outside the repository and submission package.

## Milestone Four: Database Enhancement

The database layer was enhanced with application-level schema validation, managed
indexes, bounded reads, safe single-record update/delete operations, audit timestamps,
server-side breed aggregation, a non-sensitive health summary, and database-focused
unit tests. See `DATABASE_ENHANCEMENTS.md` for the design rationale and trade-offs.
