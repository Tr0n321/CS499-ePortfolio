# Milestone Four Database Enhancements

The database layer now demonstrates production-oriented MongoDB practices:

- **Schema-aware application validation:** required identifiers, string normalization,
  numeric type checks, and rejection of unsafe field names.
- **Managed indexes:** a unique partial index on `animal_id` plus compound indexes
  supporting rescue filtering and breed searches.
- **Safe mutation methods:** `update_one` and `delete_one` require a unique animal
  identifier, avoiding accidental mass updates or deletions.
- **Bounded and sortable reads:** result limits are enforced and sortable fields are
  allow-listed.
- **Server-side aggregation:** `count_by_breed` uses `$match`, `$group`, `$sort`,
  `$limit`, and `$project` in MongoDB rather than transferring all records first.
- **Audit metadata:** new and updated records receive UTC timestamps.
- **Database-specific exceptions:** validation, conflict, not-found, and repository
  errors provide clearer handling and logging.
- **Health summary:** a non-sensitive method reports record and index status without
  exposing credentials.

## Index trade-offs

Indexes improve read and filtering speed but consume storage and add work to inserts
and updates. The selected indexes target the dashboard's actual access patterns rather
than indexing every field.

## Testing

Run from the `Enhanced_Artifact` directory:

```bash
python -m unittest discover -s tests -v
```

The tests use lightweight fakes, so they validate repository logic without requiring
live credentials or modifying a real database.
