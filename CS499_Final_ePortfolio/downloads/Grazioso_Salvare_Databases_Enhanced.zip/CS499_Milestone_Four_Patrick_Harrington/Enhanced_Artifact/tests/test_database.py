"""Unit tests for Milestone Four database validation and repository behavior."""

import unittest
from types import SimpleNamespace

import sys
import types

try:
    import pymongo  # type: ignore
except ModuleNotFoundError:
    pymongo = types.ModuleType("pymongo")
    pymongo.ASCENDING = 1
    pymongo.DESCENDING = -1
    class MongoClient:  # pragma: no cover - test import shim only
        pass
    pymongo.MongoClient = MongoClient
    collection_module = types.ModuleType("pymongo.collection")
    class Collection:  # pragma: no cover
        pass
    collection_module.Collection = Collection
    errors_module = types.ModuleType("pymongo.errors")
    class PyMongoError(Exception):
        pass
    class DuplicateKeyError(PyMongoError):
        pass
    errors_module.PyMongoError = PyMongoError
    errors_module.DuplicateKeyError = DuplicateKeyError
    sys.modules["pymongo"] = pymongo
    sys.modules["pymongo.collection"] = collection_module
    sys.modules["pymongo.errors"] = errors_module

from pymongo.errors import DuplicateKeyError

from animal_shelter import (
    AnimalConflictError,
    AnimalNotFoundError,
    AnimalShelter,
    AnimalValidationError,
)


class FakeCursor:
    def __init__(self, records):
        self.records = list(records)
        self.sort_spec = None
        self.limit_value = None

    def sort(self, spec):
        self.sort_spec = spec
        return self

    def limit(self, value):
        self.limit_value = value
        return self

    def __iter__(self):
        records = self.records
        if self.limit_value is not None:
            records = records[: self.limit_value]
        return iter(records)


class FakeCollection:
    def __init__(self):
        self.records = [{"animal_id": "A1", "breed": "Labrador"}]
        self.last_pipeline = None
        self.duplicate = False

    def create_index(self, keys, **kwargs):
        return kwargs.get("name", "index")

    def insert_one(self, document):
        if self.duplicate:
            raise DuplicateKeyError("duplicate")
        self.records.append(dict(document))
        return SimpleNamespace(inserted_id="generated-id")

    def find(self, query, projection):
        return FakeCursor(self.records)

    def update_one(self, query, update):
        if query.get("animal_id") == "missing":
            return SimpleNamespace(matched_count=0, modified_count=0)
        return SimpleNamespace(matched_count=1, modified_count=1)

    def delete_one(self, query):
        count = 0 if query.get("animal_id") == "missing" else 1
        return SimpleNamespace(deleted_count=count)

    def aggregate(self, pipeline):
        self.last_pipeline = pipeline
        return [{"breed": "Labrador", "count": 3}]

    def estimated_document_count(self):
        return len(self.records)

    def index_information(self):
        return {"_id_": {}, "ux_animals_animal_id": {}}


class DatabaseEnhancementTests(unittest.TestCase):
    def setUp(self):
        self.repository = object.__new__(AnimalShelter)
        self.repository.collection = FakeCollection()
        self.repository._settings = SimpleNamespace(database="aac", collection="animals")

    def test_create_requires_core_fields(self):
        with self.assertRaises(AnimalValidationError):
            self.repository.create({"name": "Dog"})

    def test_create_trims_strings_and_adds_audit_fields(self):
        identifier = self.repository.create(
            {"animal_id": " A2 ", "animal_type": " Dog ", "breed": " Lab "}
        )
        self.assertEqual("generated-id", identifier)
        created = self.repository.collection.records[-1]
        self.assertEqual("A2", created["animal_id"])
        self.assertIn("created_at", created)
        self.assertIn("updated_at", created)

    def test_duplicate_animal_id_raises_conflict(self):
        self.repository.collection.duplicate = True
        with self.assertRaises(AnimalConflictError):
            self.repository.create(
                {"animal_id": "A2", "animal_type": "Dog", "breed": "Lab"}
            )

    def test_read_enforces_bounded_limit(self):
        with self.assertRaises(AnimalValidationError):
            self.repository.read({}, limit=0)
        with self.assertRaises(AnimalValidationError):
            self.repository.read({}, limit=501)

    def test_read_rejects_unapproved_sort_field(self):
        with self.assertRaises(AnimalValidationError):
            self.repository.read({}, sort=[("password", 1)])

    def test_update_and_delete_are_single_record_operations(self):
        self.assertTrue(self.repository.update_one("A1", {"name": "Updated"}))
        self.assertTrue(self.repository.delete_one("A1"))
        with self.assertRaises(AnimalNotFoundError):
            self.repository.update_one("missing", {"name": "Updated"})
        with self.assertRaises(AnimalNotFoundError):
            self.repository.delete_one("missing")

    def test_aggregation_pipeline_groups_and_limits(self):
        result = self.repository.count_by_breed({"animal_type": "Dog"}, limit=10)
        self.assertEqual([{"breed": "Labrador", "count": 3}], result)
        pipeline = self.repository.collection.last_pipeline
        self.assertEqual({"$match": {"animal_type": "Dog"}}, pipeline[0])
        self.assertEqual({"$limit": 10}, pipeline[-2])

    def test_health_summary_does_not_expose_credentials(self):
        health = self.repository.database_health()
        self.assertEqual("aac", health["database"])
        self.assertNotIn("username", health)
        self.assertNotIn("password", health)


if __name__ == "__main__":
    unittest.main()
