CS 499 Milestone Four - Enhancement Three: Databases
Patrick Harrington

Original_Artifact contains the unchanged CS-340 source artifact.
Enhanced_Artifact contains the cumulative software engineering, algorithms/data
structures, and Milestone Four database enhancements.

Milestone Four database evidence:
- animal_shelter.py: validation, indexes, safe CRUD, bounded reads, aggregation,
  audit fields, and database-specific exceptions
- tests/test_database.py: database logic tests using isolated fakes
- DATABASE_ENHANCEMENTS.md: design rationale, index trade-offs, and test command
- README.md: cumulative setup and enhancement documentation

Credentials are intentionally excluded. Copy .env.example to .env and provide local
MongoDB values before running against a live database.
