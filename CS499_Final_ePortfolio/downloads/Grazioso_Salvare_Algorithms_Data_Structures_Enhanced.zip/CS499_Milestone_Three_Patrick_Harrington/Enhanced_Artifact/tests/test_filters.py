"""Unit tests for rescue-profile query, scoring, and ranking algorithms."""

import unittest

from filters import (
    RESCUE_PROFILES,
    get_profile,
    get_rescue_query,
    rank_candidates,
    score_candidate,
)


class RescueAlgorithmTests(unittest.TestCase):
    def test_known_profile_builds_expected_query(self):
        query = get_rescue_query("water")
        self.assertEqual("Dog", query["animal_type"])
        self.assertIn("Labrador Retriever Mix", query["breed"]["$in"])
        self.assertEqual(26, query["age_upon_outcome_in_weeks"]["$gte"])

    def test_unknown_profile_falls_back_to_reset(self):
        self.assertEqual("reset", get_profile("unknown").key)
        self.assertEqual({}, get_rescue_query("unknown"))

    def test_query_is_newly_constructed(self):
        first = get_rescue_query("mountain")
        first["breed"]["$in"].append("Changed Breed")
        second = get_rescue_query("mountain")
        self.assertNotIn("Changed Breed", second["breed"]["$in"])

    def test_complete_match_scores_higher_than_partial_match(self):
        profile = RESCUE_PROFILES["water"]
        complete = {
            "breed": "Labrador Retriever Mix",
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": 91,
        }
        partial = {
            "breed": "Labrador Retriever Mix",
            "sex_upon_outcome": "Neutered Male",
            "age_upon_outcome_in_weeks": 20,
        }
        complete_score, reasons = score_candidate(complete, profile)
        partial_score, _ = score_candidate(partial, profile)
        self.assertGreater(complete_score, partial_score)
        self.assertIn("preferred breed", reasons)

    def test_ranking_orders_best_candidate_first(self):
        records = [
            {"animal_id": "A1", "breed": "Newfoundland", "sex_upon_outcome": "Intact Female", "age_upon_outcome_in_weeks": 91},
            {"animal_id": "A2", "breed": "Newfoundland", "sex_upon_outcome": "Spayed Female", "age_upon_outcome_in_weeks": 30},
            {"animal_id": "A3", "breed": "Mixed Breed", "sex_upon_outcome": "Intact Female", "age_upon_outcome_in_weeks": 91},
        ]
        ranked = rank_candidates(records, "water", limit=2)
        self.assertEqual(["A1", "A2"], [item["animal_id"] for item in ranked])
        self.assertIn("match_score", ranked[0])
        self.assertGreaterEqual(ranked[0]["match_score"], ranked[1]["match_score"])

    def test_bounded_ranking_respects_limit(self):
        records = ({"animal_id": str(i)} for i in range(20))
        self.assertEqual(5, len(rank_candidates(records, "water", limit=5)))

    def test_reset_preserves_source_order(self):
        records = [{"animal_id": "A1"}, {"animal_id": "A2"}]
        self.assertEqual(records, rank_candidates(records, "reset"))


if __name__ == "__main__":
    unittest.main()
