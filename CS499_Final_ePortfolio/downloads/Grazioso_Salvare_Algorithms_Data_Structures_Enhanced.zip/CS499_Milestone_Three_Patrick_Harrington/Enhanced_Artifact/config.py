"""Application configuration loaded from environment variables.

The module keeps credentials and deployment-specific settings out of source
control. Copy ``.env.example`` to ``.env`` and export the values before
starting the application.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


class ConfigurationError(RuntimeError):
    """Raised when a required application setting is missing or invalid."""


@dataclass(frozen=True)
class MongoSettings:
    """Validated MongoDB connection settings."""

    username: str
    password: str
    host: str = "localhost"
    port: int = 27017
    database: str = "aac"
    collection: str = "animals"

    @classmethod
    def from_environment(cls) -> "MongoSettings":
        """Build settings from environment variables.

        Returns:
            A validated immutable settings object.

        Raises:
            ConfigurationError: If required credentials are absent or the
                port is not a valid integer.
        """
        username = os.getenv("MONGODB_USERNAME", "").strip()
        password = os.getenv("MONGODB_PASSWORD", "").strip()

        missing = [
            name
            for name, value in (
                ("MONGODB_USERNAME", username),
                ("MONGODB_PASSWORD", password),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "Missing required environment variable(s): " + ", ".join(missing)
            )

        port_text = os.getenv("MONGODB_PORT", "27017").strip()
        try:
            port = int(port_text)
        except ValueError as exc:
            raise ConfigurationError("MONGODB_PORT must be an integer.") from exc

        if not 1 <= port <= 65535:
            raise ConfigurationError("MONGODB_PORT must be between 1 and 65535.")

        return cls(
            username=username,
            password=password,
            host=os.getenv("MONGODB_HOST", "localhost").strip() or "localhost",
            port=port,
            database=os.getenv("MONGODB_DATABASE", "aac").strip() or "aac",
            collection=os.getenv("MONGODB_COLLECTION", "animals").strip() or "animals",
        )
