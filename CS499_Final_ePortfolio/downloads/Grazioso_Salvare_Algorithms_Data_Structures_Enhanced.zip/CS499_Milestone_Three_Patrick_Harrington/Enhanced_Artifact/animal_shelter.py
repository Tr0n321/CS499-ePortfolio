"""MongoDB data-access layer for Austin Animal Center records."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any
from urllib.parse import quote_plus

from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.errors import PyMongoError

from config import MongoSettings

LOGGER = logging.getLogger(__name__)


class AnimalShelterError(RuntimeError):
    """Raised when a database operation cannot be completed."""


class AnimalShelter:
    """Provide validated CRUD access to the animal shelter collection."""

    def __init__(self, settings: MongoSettings, client: MongoClient | None = None):
        """Initialize the repository and verify the database connection.

        Args:
            settings: Validated MongoDB settings.
            client: Optional client used for dependency injection and testing.

        Raises:
            AnimalShelterError: If MongoDB cannot be reached.
        """
        self._settings = settings
        self.client = client or MongoClient(
            self._build_uri(settings),
            serverSelectionTimeoutMS=5000,
        )
        self.database = self.client[settings.database]
        self.collection: Collection = self.database[settings.collection]

        try:
            self.client.admin.command("ping")
            LOGGER.info(
                "Connected to MongoDB database '%s', collection '%s'.",
                settings.database,
                settings.collection,
            )
        except PyMongoError as exc:
            LOGGER.exception("MongoDB connection failed.")
            raise AnimalShelterError("Unable to connect to MongoDB.") from exc

    @staticmethod
    def _build_uri(settings: MongoSettings) -> str:
        username = quote_plus(settings.username)
        password = quote_plus(settings.password)
        return f"mongodb://{username}:{password}@{settings.host}:{settings.port}"

    @staticmethod
    def _require_mapping(value: Mapping[str, Any] | None, name: str) -> dict[str, Any]:
        if value is None or not isinstance(value, Mapping):
            raise ValueError(f"{name} must be a mapping.")
        return dict(value)

    def create(self, data: Mapping[str, Any]) -> str:
        """Insert one animal record and return its generated identifier."""
        document = self._require_mapping(data, "data")
        if not document:
            raise ValueError("data cannot be empty.")

        try:
            result = self.collection.insert_one(document)
            LOGGER.info("Inserted animal record %s.", result.inserted_id)
            return str(result.inserted_id)
        except PyMongoError as exc:
            LOGGER.exception("Create operation failed.")
            raise AnimalShelterError("Unable to create animal record.") from exc

    def read(self, query: Mapping[str, Any] | None = None, limit: int = 0) -> list[dict[str, Any]]:
        """Return matching animal records without MongoDB object identifiers."""
        criteria = self._require_mapping(query or {}, "query")
        if limit < 0:
            raise ValueError("limit cannot be negative.")

        try:
            cursor = self.collection.find(criteria, {"_id": False})
            if limit:
                cursor = cursor.limit(limit)
            records = list(cursor)
            LOGGER.info("Read %d animal record(s).", len(records))
            return records
        except PyMongoError as exc:
            LOGGER.exception("Read operation failed.")
            raise AnimalShelterError("Unable to read animal records.") from exc

    def update(self, query: Mapping[str, Any], new_values: Mapping[str, Any]) -> int:
        """Update matching records and return the number modified."""
        criteria = self._require_mapping(query, "query")
        updates = self._require_mapping(new_values, "new_values")
        if not criteria:
            raise ValueError("query cannot be empty for an update operation.")
        if not updates:
            raise ValueError("new_values cannot be empty.")

        try:
            result = self.collection.update_many(criteria, {"$set": updates})
            LOGGER.info("Modified %d animal record(s).", result.modified_count)
            return result.modified_count
        except PyMongoError as exc:
            LOGGER.exception("Update operation failed.")
            raise AnimalShelterError("Unable to update animal records.") from exc

    def delete(self, query: Mapping[str, Any]) -> int:
        """Delete matching records and return the number deleted."""
        criteria = self._require_mapping(query, "query")
        if not criteria:
            raise ValueError("query cannot be empty for a delete operation.")

        try:
            result = self.collection.delete_many(criteria)
            LOGGER.info("Deleted %d animal record(s).", result.deleted_count)
            return result.deleted_count
        except PyMongoError as exc:
            LOGGER.exception("Delete operation failed.")
            raise AnimalShelterError("Unable to delete animal records.") from exc

    def close(self) -> None:
        """Release the MongoDB client connection."""
        self.client.close()
        LOGGER.info("MongoDB connection closed.")
