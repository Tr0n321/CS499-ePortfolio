"""Algorithms and data structures for rescue-candidate selection.

The original dashboard used hardcoded MongoDB query dictionaries.  This
module models each rescue category as an immutable profile, builds database
queries from those profiles, scores individual animals, and uses a bounded
heap to return the strongest candidates efficiently.
"""

from __future__ import annotations

from dataclasses import dataclass
from heapq import nlargest
from typing import Any, Iterable, Mapping, Sequence

MongoQuery = dict[str, Any]
AnimalRecord = Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class RescueProfile:
    """Selection rules and scoring weights for one rescue discipline."""

    key: str
    label: str
    breeds: tuple[str, ...]
    preferred_sex: str | None
    minimum_age_weeks: float | None
    maximum_age_weeks: float | None
    breed_weight: int = 50
    sex_weight: int = 20
    age_weight: int = 30

    def build_query(self) -> MongoQuery:
        """Create a MongoDB pre-filter for records eligible for this profile."""
        if self.key == "reset":
            return {}

        query: MongoQuery = {"animal_type": "Dog"}
        if self.breeds:
            query["breed"] = {"$in": list(self.breeds)}
        if self.preferred_sex:
            query["sex_upon_outcome"] = self.preferred_sex

        age_range: dict[str, float] = {}
        if self.minimum_age_weeks is not None:
            age_range["$gte"] = self.minimum_age_weeks
        if self.maximum_age_weeks is not None:
            age_range["$lte"] = self.maximum_age_weeks
        if age_range:
            query["age_upon_outcome_in_weeks"] = age_range
        return query


RESCUE_PROFILES: Mapping[str, RescueProfile] = {
    "reset": RescueProfile("reset", "Reset", (), None, None, None),
    "water": RescueProfile(
        "water",
        "Water Rescue",
        (
            "Labrador Retriever Mix",
            "Chesapeake Bay Retriever",
            "Newfoundland",
        ),
        "Intact Female",
        26,
        156,
    ),
    "mountain": RescueProfile(
        "mountain",
        "Mountain or Wilderness Rescue",
        (
            "German Shepherd",
            "Alaskan Malamute",
            "Old English Sheepdog",
            "Siberian Husky",
            "Rottweiler",
        ),
        "Intact Male",
        26,
        156,
    ),
    "disaster": RescueProfile(
        "disaster",
        "Disaster or Individual Tracking",
        (
            "Doberman Pinscher",
            "German Shepherd",
            "Golden Retriever",
            "Bloodhound",
            "Rottweiler",
        ),
        "Intact Male",
        20,
        300,
    ),
}

FILTER_OPTIONS = [
    {"label": profile.label, "value": profile.key}
    for profile in RESCUE_PROFILES.values()
]


def get_profile(filter_type: str | None) -> RescueProfile:
    """Return a rescue profile, defaulting safely to the reset profile."""
    return RESCUE_PROFILES.get(filter_type or "reset", RESCUE_PROFILES["reset"])


def get_rescue_query(filter_type: str | None) -> MongoQuery:
    """Build a new MongoDB query for the selected rescue category."""
    return get_profile(filter_type).build_query()


def _safe_number(value: Any) -> float | None:
    """Convert numeric input to float without raising callback-breaking errors."""
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def score_candidate(record: AnimalRecord, profile: RescueProfile) -> tuple[float, tuple[str, ...]]:
    """Score one animal from 0 to 100 and explain the awarded points.

    Breed and sex are exact-match criteria. Age receives partial credit based
    on distance from the middle of the preferred range, which distinguishes
    candidates that would otherwise tie under a strict Boolean filter.
    """
    if profile.key == "reset":
        return 0.0, ("No rescue profile selected",)

    score = 0.0
    reasons: list[str] = []

    breed = str(record.get("breed", "")).strip()
    if breed in profile.breeds:
        score += profile.breed_weight
        reasons.append("preferred breed")

    sex = str(record.get("sex_upon_outcome", "")).strip()
    if profile.preferred_sex and sex == profile.preferred_sex:
        score += profile.sex_weight
        reasons.append("preferred sex")

    age = _safe_number(record.get("age_upon_outcome_in_weeks"))
    low = profile.minimum_age_weeks
    high = profile.maximum_age_weeks
    if age is not None and low is not None and high is not None and low <= age <= high:
        midpoint = (low + high) / 2
        half_span = max((high - low) / 2, 1)
        closeness = 1 - abs(age - midpoint) / half_span
        age_points = profile.age_weight * (0.5 + 0.5 * max(closeness, 0.0))
        score += age_points
        reasons.append("age within preferred range")

    return round(min(score, 100.0), 2), tuple(reasons)


def rank_candidates(
    records: Iterable[AnimalRecord],
    filter_type: str | None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Return the top rescue candidates ordered by descending suitability.

    ``heapq.nlargest`` keeps only ``limit`` candidates in memory, producing
    O(n log k) time and O(k) auxiliary space for n records and k results.
    Stable sequence numbers preserve source order when two scores are equal.
    """
    if limit <= 0:
        return []

    profile = get_profile(filter_type)
    if profile.key == "reset":
        return [dict(record) for _, record in zip(range(limit), records)]

    scored: list[tuple[float, int, dict[str, Any]]] = []
    for sequence, record in enumerate(records):
        score, reasons = score_candidate(record, profile)
        enriched = dict(record)
        enriched["match_score"] = score
        enriched["match_reasons"] = ", ".join(reasons) if reasons else "limited profile match"
        scored.append((score, -sequence, enriched))

    best = nlargest(limit, scored, key=lambda item: (item[0], item[1]))
    return [record for _, _, record in best]
