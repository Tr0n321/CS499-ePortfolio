from pymongo import MongoClient


class AnimalShelter(object):

    def __init__(self, username, password):
        """
        Initialize MongoDB connection for the AAC database.
        """
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Insert a document into the animals collection.
        Returns True if successful, otherwise False.
        """
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Create error:", e)
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """
        Query documents from the animals collection.
        Returns a list of matching documents if successful,
        otherwise returns an empty list.
        """
        if query is not None:
            try:
                data = self.collection.find(query, {"_id": False})
                return list(data)
            except Exception as e:
                print("Read error:", e)
                return []
        else:
            return []

    def update(self, query, new_values):
        """
        Update document(s) in the animals collection.
        Returns the number of documents modified.
        """
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print("Update error:", e)
                return 0
        else:
            return 0

    def delete(self, query):
        """
        Delete document(s) from the animals collection.
        Returns the number of documents deleted.
        """
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print("Delete error:", e)
                return 0
        else:
            return 0