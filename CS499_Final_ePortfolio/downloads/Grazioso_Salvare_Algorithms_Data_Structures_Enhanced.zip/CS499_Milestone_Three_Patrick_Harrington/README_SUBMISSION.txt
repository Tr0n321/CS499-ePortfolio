CS 499 Milestone Three - Enhancement Two: Algorithms and Data Structures
Patrick Harrington

Original_Artifact preserves the CS-340 source artifact.
Enhanced_Artifact contains the cumulative Milestone Two software-engineering improvements plus the Milestone Three algorithm and data-structure enhancements.

Primary Milestone Three changes:
- immutable RescueProfile data structures
- dynamic MongoDB query construction
- weighted rescue-suitability scoring
- stable bounded-heap top-k ranking
- explainable match scores and reasons
- expanded unit tests

No real MongoDB credentials are included.
