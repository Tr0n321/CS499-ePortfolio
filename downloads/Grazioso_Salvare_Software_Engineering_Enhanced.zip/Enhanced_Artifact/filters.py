"""Reusable rescue-type filter definitions for the dashboard."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

MongoQuery = dict[str, Any]


RESCUE_FILTERS: Mapping[str, MongoQuery] = {
    "reset": {},
    "water": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Labrador Retriever Mix",
                "Chesapeake Bay Retriever",
                "Newfoundland",
            ]
        },
        "sex_upon_outcome": "Intact Female",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "mountain": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "German Shepherd",
                "Alaskan Malamute",
                "Old English Sheepdog",
                "Siberian Husky",
                "Rottweiler",
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "disaster": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Doberman Pinscher",
                "German Shepherd",
                "Golden Retriever",
                "Bloodhound",
                "Rottweiler",
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
    },
}

FILTER_OPTIONS = [
    {"label": "Reset", "value": "reset"},
    {"label": "Water Rescue", "value": "water"},
    {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
    {"label": "Disaster or Individual Tracking", "value": "disaster"},
]


def get_rescue_query(filter_type: str | None) -> MongoQuery:
    """Return a safe copy of the MongoDB query for a rescue category.

    Unknown or missing values intentionally fall back to the unfiltered query
    so the dashboard remains available rather than failing inside a callback.
    """
    key = filter_type if filter_type in RESCUE_FILTERS else "reset"
    return deepcopy(RESCUE_FILTERS[key])
