"""Unit tests for reusable rescue filter behavior."""

import unittest

from filters import RESCUE_FILTERS, get_rescue_query


class RescueFilterTests(unittest.TestCase):
    def test_known_filter_returns_expected_query(self):
        query = get_rescue_query("water")
        self.assertEqual("Dog", query["animal_type"])
        self.assertIn("Labrador Retriever Mix", query["breed"]["$in"])

    def test_unknown_filter_falls_back_to_reset(self):
        self.assertEqual({}, get_rescue_query("not-a-filter"))

    def test_returned_query_is_a_copy(self):
        query = get_rescue_query("mountain")
        query["breed"]["$in"].append("Changed Breed")
        self.assertNotIn("Changed Breed", RESCUE_FILTERS["mountain"]["breed"]["$in"])


if __name__ == "__main__":
    unittest.main()
