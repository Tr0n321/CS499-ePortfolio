# Grazioso Salvare Dashboard - Software Design and Engineering Enhancement

This folder contains the refactored CS-340 dashboard prepared for CS 499 Milestone Two.

## Enhancement summary

- Replaced hardcoded credentials with validated environment-based configuration.
- Separated configuration, logging, database access, filtering rules, and UI concerns.
- Replaced broad `except Exception` blocks and console printing with targeted PyMongo exception handling, application-specific exceptions, and structured logging.
- Added input validation to CRUD operations and blocked accidental update/delete calls with empty queries.
- Added type hints, docstrings, dependency injection support, and a clean application entry point.
- Added a reusable filter module and unit tests.
- Added an accessible status message and logo alternative text.
- Added dependency documentation and startup instructions.

## Project structure

- `app.py` - Dash layout, callbacks, and startup logic
- `animal_shelter.py` - validated MongoDB CRUD repository
- `config.py` - immutable environment-based settings
- `filters.py` - reusable rescue filter query definitions
- `logger_config.py` - centralized logging setup
- `tests/test_filters.py` - unit tests for filter behavior
- `assets/` - dashboard logo

## Setup

1. Create and activate a Python virtual environment.
2. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

3. Export the required MongoDB settings. Example on macOS/Linux:

   ```bash
   export MONGODB_USERNAME="aacuser"
   export MONGODB_PASSWORD="your_password"
   export MONGODB_HOST="localhost"
   export MONGODB_PORT="27017"
   export MONGODB_DATABASE="aac"
   export MONGODB_COLLECTION="animals"
   ```

4. Run the application:

   ```bash
   python app.py
   ```

5. Open `http://127.0.0.1:8050` in a browser.

## Run tests

From the enhanced artifact folder:

```bash
python -m unittest discover -s tests -v
```

## Security note

`.env.example` contains placeholders only. Real credentials must remain outside the repository and submission package.
